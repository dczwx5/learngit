declare class BattleMenuWindowSkin extends eui.Skin{
}
declare class BattleRecordPanelSkin extends eui.Skin{
}
declare class BattleSettleViewSkin extends eui.Skin{
}
declare class BattleViewSkin extends eui.Skin{
}
declare class CardGroupSkin extends eui.Skin{
}
declare class CardSkin extends eui.Skin{
}
declare class ExpPgBarSkin extends eui.Skin{
}
declare class FlyScoreTipSkin extends eui.Skin{
}
declare class LvBlockSkin extends eui.Skin{
}
declare class RebirthConfirmWindowSkin extends eui.Skin{
}
declare class RefreshBtnSkin extends eui.Skin{
}
declare class RubbishBinCellSkin extends eui.Skin{
}
declare class RubbishBinSkin extends eui.Skin{
}
declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare class CardSkinItemRendererSkin extends eui.Skin{
}
declare class SkinWindowSkin extends eui.Skin{
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare class PopupWindowSkin extends eui.Skin{
}
declare class HelpWindowSkin extends eui.Skin{
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare class MainViewSkin extends eui.Skin{
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare class ShareCanvasViewSkin extends eui.Skin{
}
declare class WxOtherGameIconSkin extends eui.Skin{
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
