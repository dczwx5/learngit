/**
 * Created by MuZi on 2018/9/10.
 */
var Enum_HttpRespCode;
(function (Enum_HttpRespCode) {
    Enum_HttpRespCode[Enum_HttpRespCode["undefined"] = -1] = "undefined";
    Enum_HttpRespCode[Enum_HttpRespCode["SUCCESS"] = 1] = "SUCCESS";
})(Enum_HttpRespCode || (Enum_HttpRespCode = {}));
//# sourceMappingURL=Enum_HttpRespCode.js.map