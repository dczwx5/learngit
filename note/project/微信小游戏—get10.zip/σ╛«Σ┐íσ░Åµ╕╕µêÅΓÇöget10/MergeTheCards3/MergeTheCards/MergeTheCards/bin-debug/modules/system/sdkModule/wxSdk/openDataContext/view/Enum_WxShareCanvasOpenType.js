var Enum_WxShareCanvasOpenType;
(function (Enum_WxShareCanvasOpenType) {
    Enum_WxShareCanvasOpenType[Enum_WxShareCanvasOpenType["FRIEND_RANK_LIST"] = 1] = "FRIEND_RANK_LIST";
    Enum_WxShareCanvasOpenType[Enum_WxShareCanvasOpenType["GROUP_RANK_LIST"] = 2] = "GROUP_RANK_LIST";
})(Enum_WxShareCanvasOpenType || (Enum_WxShareCanvasOpenType = {}));
//# sourceMappingURL=Enum_WxShareCanvasOpenType.js.map