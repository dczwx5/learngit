var SDK;
(function (SDK) {
    /**
     * 分享结果枚举
     */
    var Enum_SDKShareResult;
    (function (Enum_SDKShareResult) {
        /**
         * 分享失败
         */
        Enum_SDKShareResult[Enum_SDKShareResult["FAILD"] = 0] = "FAILD";
        /**
         * 分享成功
         */
        Enum_SDKShareResult[Enum_SDKShareResult["SUCCESE"] = 1] = "SUCCESE";
    })(Enum_SDKShareResult = SDK.Enum_SDKShareResult || (SDK.Enum_SDKShareResult = {}));
})(SDK || (SDK = {}));
//# sourceMappingURL=Enum_SDKShareResult.js.map