/**
 * 看视频关联的业务标识
 */
// class Enum_WxWatchVideoFlag{
//     /**
//      * 刷新手牌
//      * @type {string}
//      */
//     public static readonly REFRESH_HAND_CARD = 'REFRESH_HAND_CARD';
//     /**
//      * 复活
//      * @type {string}
//      */
//     public static readonly REBIRTH = 'REBIRTH';
// }
/**
 * 看视频关联的业务标识
 */
var Enum_WxWatchVideoFlag;
(function (Enum_WxWatchVideoFlag) {
    /**刷新手牌*/
    Enum_WxWatchVideoFlag[Enum_WxWatchVideoFlag["REFRESH_HAND_CARD"] = 1] = "REFRESH_HAND_CARD";
    /**复活*/
    Enum_WxWatchVideoFlag[Enum_WxWatchVideoFlag["REBIRTH"] = 2] = "REBIRTH";
})(Enum_WxWatchVideoFlag || (Enum_WxWatchVideoFlag = {}));
//# sourceMappingURL=Enum_WxWatchVideoFlag.js.map