var Enum_CardType;
(function (Enum_CardType) {
    /**普通牌*/
    Enum_CardType[Enum_CardType["NORMAL"] = 1] = "NORMAL";
    /**回收牌*/
    Enum_CardType[Enum_CardType["RESTOR"] = 2] = "RESTOR";
    /**炸弹牌*/
    Enum_CardType[Enum_CardType["BOMB"] = 3] = "BOMB";
    /**万能牌*/
    Enum_CardType[Enum_CardType["UNIVERSAL"] = 4] = "UNIVERSAL";
})(Enum_CardType || (Enum_CardType = {}));
//# sourceMappingURL=Enum_CardType.js.map