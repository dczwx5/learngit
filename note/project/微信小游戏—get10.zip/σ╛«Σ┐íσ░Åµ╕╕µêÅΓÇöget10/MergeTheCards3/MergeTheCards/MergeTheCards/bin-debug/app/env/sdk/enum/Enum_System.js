var Enum_System;
(function (Enum_System) {
    Enum_System[Enum_System["ANDROID"] = 1] = "ANDROID";
    Enum_System[Enum_System["IOS"] = 2] = "IOS";
})(Enum_System || (Enum_System = {}));
//# sourceMappingURL=Enum_System.js.map