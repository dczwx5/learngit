var Enum_WxWatchVideoResult;
(function (Enum_WxWatchVideoResult) {
    Enum_WxWatchVideoResult[Enum_WxWatchVideoResult["COMPLETE"] = 1] = "COMPLETE";
    Enum_WxWatchVideoResult[Enum_WxWatchVideoResult["GIVE_UP"] = 2] = "GIVE_UP";
    Enum_WxWatchVideoResult[Enum_WxWatchVideoResult["NO_AD_COUNT"] = 3] = "NO_AD_COUNT";
    Enum_WxWatchVideoResult[Enum_WxWatchVideoResult["ERROR"] = 4] = "ERROR";
})(Enum_WxWatchVideoResult || (Enum_WxWatchVideoResult = {}));
//# sourceMappingURL=Enum_WxWatchVideoResult.js.map