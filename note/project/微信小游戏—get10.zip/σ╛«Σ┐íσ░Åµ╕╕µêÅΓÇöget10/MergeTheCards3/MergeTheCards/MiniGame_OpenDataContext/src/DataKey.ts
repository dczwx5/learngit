/**
 * KVDataList里的Key值
 */
class DataKey{
    // public static readonly STAR:string = "star";
    public static readonly SCORE:string = "score";
    public static readonly SCORE_MAX:string = "score_max";
    public static readonly SCORE_WEEK:string = "score_week";
    public static readonly SCORE_TIME:string = "score_time";
}
