class ContextEvent extends egret.Event{
    public static readonly CLOSE_CONTEXT:string = "ContextEvent_CLOSE_CONTEXT";
}
