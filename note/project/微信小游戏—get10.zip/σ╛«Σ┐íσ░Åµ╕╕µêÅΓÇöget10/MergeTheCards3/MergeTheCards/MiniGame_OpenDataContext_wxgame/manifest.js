require("js/egret.min.js")
require("js/game.min.js")
require("js/main.min.js")