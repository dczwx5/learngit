"use strict";
cc._RF.push(module, '071e8RIRwVKVrwEgi3h53SX', 'CHotUpdate');
// Script/CHotUpdate.ts

Object.defineProperty(exports, "__esModule", { value: true });
var CJSB_1 = require("./CJSB");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var CHotUpdate = /** @class */ (function (_super) {
    __extends(CHotUpdate, _super);
    function CHotUpdate() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CHotUpdate.prototype.onDestroy = function () {
        if (this._am) {
            this._am.setEventCallback(null);
        }
    };
    CHotUpdate.prototype.onLoad = function () {
        if (!cc.sys.isNative) {
            return;
        }
        this._check_process = new CCheckUpdateEventProcess();
        this._update_process = new CHotUpdateEventProcess();
        this._storagePath = CJSB_1.CJSB.getWritablePath() + 'test-remote-assset';
        cc.log('remote asset storage path ', this._storagePath);
        // Init with empty manifest url for testing custom manifest
        this._am = new CJSB_1.CAssetsManager('', this._storagePath, this._versionCompareHandle);
        this._am.setVerifyCallback(this._onVerifyHandle.bind(this));
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            // Some Android device may slow down the download process when concurrent tasks is too much.
            // The value may not be accurate, please do more test and find what's most suitable for your game.
            this._am.setMaxConcurrentTask(2);
        }
        if (this._am.isUnInited()) {
            var url = this.manifest.nativeUrl;
            if (cc.loader.md5Pipe) {
                url = cc.loader.md5Pipe.transformURL(url);
            }
            this._am.loadLocalManifest(url);
        }
        this._am.setEventCallback(this._onUpdateEvent.bind(this));
    };
    CHotUpdate.prototype._onUpdateEvent = function (event) {
        var processData;
        if (this._isProcessCheck) {
            processData = this._check_process.proccess(event);
            this._callCheckUpdatHandler(processData.success, processData.hasNew, processData.msg);
            this._isUpdating = false;
            this._isProcessCheck = false;
        }
        else if (this._isProcessUpdate) {
            // 更新中
            processData = this._update_process.proccess(event);
            if (processData.isProcess) {
                this._callProccessHandler(event);
            }
            else {
                this._callHotUpdatHandler(processData.success, processData.msg);
                this._isUpdating = false;
                this._isProcessUpdate = false;
            }
        }
    };
    CHotUpdate.prototype._callCheckUpdatHandler = function (sucess, hasNew, msg) {
        if (this.checkUpdateHandler) {
            this.checkUpdateHandler(sucess, hasNew, msg);
        }
    };
    CHotUpdate.prototype._callHotUpdatHandler = function (sucess, msg) {
        if (this.hotUpdateHandler) {
            this.hotUpdateHandler(sucess, msg);
        }
    };
    CHotUpdate.prototype._callProccessHandler = function (event) {
        if (this.processHandler) {
            this.processHandler(event.getPercent(), event.getDownloadedBytes(), event.getTotalBytes(), event.getPercentByFile(), event.getDownloadedFiles(), event.getTotalFiles());
        }
    };
    // 版本比例函数
    CHotUpdate.prototype._versionCompareHandle = function (versionA, versionB) {
        cc.log("JS Custom Version Compare: version A is " + versionA + ', version B is ' + versionB);
        var vA = versionA.split('.');
        var vB = versionB.split('.');
        for (var i = 0; i < vA.length; ++i) {
            var a = parseInt(vA[i]);
            var b = parseInt(vB[i] || 0);
            if (a === b) {
                continue;
            }
            else {
                return a - b;
            }
        }
        if (vB.length > vA.length) {
            return -1;
        }
        else {
            return 0;
        }
    };
    // 验证成功回调
    CHotUpdate.prototype._onVerifyHandle = function (path, asset) {
        // When asset is compressed, we don't need to check its md5, because zip file have been deleted.
        var compressed = asset.compressed;
        // Retrieve the correct md5 value.
        var expectedMD5 = asset.md5;
        // asset.path is relative path and path is absolute.
        var relativePath = asset.path;
        // The size of asset file, but this value could be absent.
        var size = asset.size;
        cc.log('======> verify sucess');
        return true;
    };
    // =========================检查更新
    CHotUpdate.prototype.update = function () {
        if (!this._isUpdating) {
            if (this._quireToCheckUpdate) {
                this.checkUpdate();
            }
            else if (this._quireToUpdate) {
                this.hotUpdate();
            }
        }
    };
    CHotUpdate.prototype.checkUpdate = function () {
        if (this._isUpdating) {
            if (this._isProcessUpdate) {
                this._quireToCheckUpdate = true;
            }
            return;
        }
        if (this._am.isUnInited()) {
            this._quireToCheckUpdate = true;
            return;
        }
        if (!this._am.isManifestReady()) {
            this._quireToCheckUpdate = true;
            return;
        }
        this._quireToCheckUpdate = false;
        this._isUpdating = true;
        this._isProcessCheck = true;
        this._am.checkUpdate();
    };
    // =========================更新
    CHotUpdate.prototype.hotUpdate = function () {
        if (this._isUpdating) {
            if (this._isProcessCheck) {
                this._quireToUpdate = true;
            }
            else if (this._isProcessUpdate) {
                // 已经在更新，操作丢弃
            }
            return;
        }
        if (this._am.isUnInited()) {
            this._quireToUpdate = true;
            return;
        }
        if (!this._am.isManifestReady()) {
            this._quireToUpdate = true;
            return;
        }
        this._quireToUpdate = false;
        this._isUpdating = true;
        this._isProcessUpdate = true;
        this._am.update();
    };
    __decorate([
        property(cc.Asset)
    ], CHotUpdate.prototype, "manifest", void 0);
    CHotUpdate = __decorate([
        ccclass
    ], CHotUpdate);
    return CHotUpdate;
}(cc.Component));
exports.default = CHotUpdate;
var CUpdateData = /** @class */ (function () {
    function CUpdateData() {
    }
    return CUpdateData;
}());
var CCheckUpdateEventProcess = /** @class */ (function () {
    function CCheckUpdateEventProcess() {
    }
    CCheckUpdateEventProcess.prototype.proccess = function (event) {
        var ret = new CUpdateData();
        var code = event.getEventCode();
        var msg = event.getMessage();
        var success = false;
        var hasNew = false;
        switch (code) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                cc.error("No local manifest file found, hot update skipped.", msg);
                success = hasNew = false;
                break;
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                cc.error("Fail to download manifest file, hot update skipped.", msg);
                success = hasNew = false;
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                cc.error("Already up to date with the latest remote version.", msg);
                success = true;
                hasNew = false;
                break;
            case jsb.EventAssetsManager.NEW_VERSION_FOUND:
                cc.log('New version found, please try to update.', msg);
                success = true;
                hasNew = true;
                break;
            default:
                cc.error("other error ", msg);
                success = hasNew = false;
                return;
        }
        ret.hasNew = hasNew;
        ret.success = success;
        ret.msg = msg;
        return ret;
    };
    return CCheckUpdateEventProcess;
}());
var CHotUpdateEventProcess = /** @class */ (function () {
    function CHotUpdateEventProcess() {
    }
    CHotUpdateEventProcess.prototype.proccess = function (event) {
        var ret = new CUpdateData();
        var code = event.getEventCode();
        var msg = event.getMessage();
        var success = false;
        var finish = false;
        var isProcess = false;
        if (code == jsb.EventAssetsManager.UPDATE_PROGRESSION) {
            isProcess = true;
            success = true;
            return;
        }
        switch (code) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                cc.error('No local manifest file found, hot update skipped.', msg);
                break;
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                cc.error('Fail to download manifest file, hot update skipped.');
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                cc.error('Already up to date with the latest remote version.');
                break;
            case jsb.EventAssetsManager.UPDATE_FINISHED:
                cc.log('Update finished. ' + event.getMessage());
                success = true;
                finish = true;
                break;
            case jsb.EventAssetsManager.UPDATE_FAILED:
                cc.error('Update failed. ' + event.getMessage());
                break;
            case jsb.EventAssetsManager.ERROR_UPDATING:
                cc.error('Asset update error: ' + event.getAssetId() + ', ' + event.getMessage());
                break;
            case jsb.EventAssetsManager.ERROR_DECOMPRESS:
                cc.log(event.getMessage());
                break;
            default:
                break;
        }
        ret.msg = msg;
        ret.success = success;
        ret.finish = finish;
        ret.isProcess = isProcess;
        return ret;
    };
    return CHotUpdateEventProcess;
}());

cc._RF.pop();