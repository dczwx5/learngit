"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'Helloworld');
// Script/Helloworld.ts

Object.defineProperty(exports, "__esModule", { value: true });
var CHotUpdate_1 = require("./CHotUpdate");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.version = null;
        return _this;
    }
    Helloworld.prototype.start = function () {
        // init logic
        // this.version.string = '1.0';
        // let tempList = ['爷', '姑', '舅', '妈', '娘', '伯', '姨', '奶'];
        // let str = '';
        // for (let i:number = 0; i < 1000; i++) {
        //     let rnd = Math.floor(Math.random() * tempList.length);
        //     str += '你' + (i+7) + '大' + tempList[rnd] + ' ';
        // }
        // cc.log(str);
        var hot = this.getComponent(CHotUpdate_1.default);
        hot.checkUpdateHandler = this.checkUpdateHandler;
        hot.hotUpdateHandler = this.hotUpdateHandler;
        hot.processHandler = this.processHandler;
        hot.checkUpdate();
    };
    Helloworld.prototype.checkUpdateHandler = function (sucess, hasNew, msg) {
        if (sucess && hasNew) {
            var hot = this.getComponent(CHotUpdate_1.default);
            hot.hotUpdate();
        }
    };
    Helloworld.prototype.hotUpdateHandler = function (sucess, msg) {
        cc.log('热更新， ', sucess);
        ;
    };
    Helloworld.prototype.processHandler = function (byteProgress, loadedByte, totalByte, fileProgress, downloadedFiles, totalFiles) {
    };
    __decorate([
        property(cc.Label)
    ], Helloworld.prototype, "version", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();