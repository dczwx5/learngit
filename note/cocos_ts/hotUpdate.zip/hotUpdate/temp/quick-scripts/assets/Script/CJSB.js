(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/CJSB.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '4dd32xHy8dKvKRTNKs/7ol3', 'CJSB', __filename);
// Script/CJSB.ts

Object.defineProperty(exports, "__esModule", { value: true });
var CJSB = /** @class */ (function () {
    function CJSB() {
    }
    CJSB.getWritablePath = function () {
        return (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/');
    };
    CJSB.getSearchPaths = function () {
        return jsb.fileUtils.getSearchPaths();
    };
    CJSB.setSearchPaths = function (searchPaths) {
        jsb.fileUtils.setSearchPaths(searchPaths);
    };
    return CJSB;
}());
exports.CJSB = CJSB;
var CAssetsManager = /** @class */ (function () {
    function CAssetsManager(manifestUrl, storagePath, versionCompareHandle) {
        this._assetsManager = new jsb.AssetsManager(manifestUrl, storagePath, versionCompareHandle);
    }
    CAssetsManager.prototype.setVerifyCallback = function (callback) {
        this._assetsManager.setVerifyCallback(callback);
    };
    CAssetsManager.prototype.setEventCallback = function (callback) {
        this._assetsManager.setEventCallback(callback);
    };
    // 设置并行数量，有些安卓机并行太大会有问题
    CAssetsManager.prototype.setMaxConcurrentTask = function (maxNum) {
        this._assetsManager.setMaxConcurrentTask(maxNum);
    };
    // 检查更新
    CAssetsManager.prototype.checkUpdate = function () {
        this._assetsManager.checkUpdate();
    };
    // 更新
    CAssetsManager.prototype.update = function () {
        this._assetsManager.update();
    };
    // 下载之前失败的资源
    CAssetsManager.prototype.downloadFailedAssets = function () {
        this._assetsManager.downloadFailedAssets();
    };
    CAssetsManager.prototype.getState = function () {
        return this._assetsManager.getState();
    };
    // 是否未启动
    CAssetsManager.prototype.isUnInited = function () {
        return this.getState === jsb.AssetsManager.State.UNINITED;
    };
    /**
     * 加载本地manifest文件
     * 注:内部会自动获取缓存目录 「storePath目录」 下的manifest进行比较以确定使用哪个manifest
     * 如果nativeUrl为本地动态获取的话，需要改c++ AssetsManager对应底层逻辑代码
     * @param nativeUrl manifest本地路径
     */
    CAssetsManager.prototype.loadLocalManifest = function (nativeUrl) {
        var url = nativeUrl;
        if (cc.loader.md5Pipe) {
            url = cc.loader.md5Pipe.transformURL(url);
        }
        this._assetsManager.loadLocalManifest(url);
    };
    CAssetsManager.prototype.getLocalManifest = function () {
        return this._assetsManager.getLocalManifest();
    };
    CAssetsManager.prototype.getLocalVersion = function () {
        if (this._assetsManager) {
            return this._assetsManager.getLocalManifest().getVersion();
        }
        else {
            return "0";
        }
    };
    CAssetsManager.prototype.isManifestReady = function () {
        var manifest = this.getLocalManifest();
        return manifest && manifest.isLoaded();
    };
    // 将每个子游戏都设成了一个searchpath, 使用searchpath有很多，增加了查找代价
    //  /**
    //  *  分包策略
    //  *  1.路径:jsb.fileUtils.getWritablePath() + "drdz/hotupdate/"+gameCode
    //  *  2.packageName策略: Main(主包) Game1(子包:场景名)
    //  * 根据包名添加一个搜索路径到小标0
    //  * 如果已经存在则位置提前到下标0
    //  * @param gameCode 包名
    //  */
    // public addSearchPath(gameCode: string): void {
    //     let pakcageUrl = CJSB.getWritablePath() + "drdz/hotupdate/" + gameCode;
    //     var searchPaths: string[] = CJSB.getSearchPaths();
    //     //数组去重
    //     let index = searchPaths.indexOf(pakcageUrl);
    //     if (index === 0) {
    //         return; //如果已经是第一位则什么也不做
    //     }
    //     if (index >= 1) {
    //         searchPaths.splice(index, 1);
    //     }
    //     searchPaths = [pakcageUrl].concat(searchPaths)
    //     // searchPaths.unshift(pakcageUrl);     //unshift() 方法无法在 Internet Explorer 中正确地工作！
    //     CJSB.setSearchPaths(searchPaths);
    //     cc.sys.localStorage.setItem('HotUpdateSearchPaths', JSON.stringify(searchPaths));
    // }
    /**
     * 字节数转大小(B KB MB GB...)
     * @param bytes 字节数
     */
    CAssetsManager.prototype.bytesToSize = function (bytes) {
        if (bytes === 0)
            return '0B';
        var k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'], i = Math.floor(Math.log(bytes) / Math.log(k));
        return (bytes / Math.pow(k, i)).toPrecision(2) + '' + sizes[i];
    };
    CAssetsManager.EventCode = {
        ERROR_NO_LOCAL_MANIFEST: 0,
        ERROR_DOWNLOAD_MANIFEST: 1,
        ERROR_PARSE_MANIFEST: 2,
        NEW_VERSION_FOUND: 3,
        ALREADY_UP_TO_DATE: 4,
        UPDATE_PROGRESSION: 5,
        ASSET_UPDATED: 6,
        ERROR_UPDATING: 7,
        UPDATE_FINISHED: 8,
        UPDATE_FAILED: 9,
        ERROR_DECOMPRESS: 10,
    };
    return CAssetsManager;
}());
exports.CAssetsManager = CAssetsManager;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=CJSB.js.map
        