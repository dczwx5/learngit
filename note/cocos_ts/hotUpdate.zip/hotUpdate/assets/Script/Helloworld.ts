import CHotUpdate from "./CHotUpdate";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Helloworld extends cc.Component {

    @property(cc.Label)
    version: cc.Label = null;


    start () {
        // init logic
        // this.version.string = '1.0';

        // let tempList = ['爷', '姑', '舅', '妈', '娘', '伯', '姨', '奶'];
        // let str = '';
        // for (let i:number = 0; i < 1000; i++) {
        //     let rnd = Math.floor(Math.random() * tempList.length);
        //     str += '你' + (i+7) + '大' + tempList[rnd] + ' ';
        // }
        // cc.log(str);

        let hot = this.getComponent(CHotUpdate);
        hot.checkUpdateHandler = this.checkUpdateHandler;
        hot.hotUpdateHandler = this.hotUpdateHandler;
        hot.processHandler = this.processHandler;

        hot.checkUpdate();

    }

    checkUpdateHandler(sucess:boolean, hasNew, msg:string) {
        if (sucess && hasNew) {
            let hot = this.getComponent(CHotUpdate);
            hot.hotUpdate();
        }
    }
    hotUpdateHandler(sucess:boolean, msg:string){
        cc.log('热更新， ', sucess);;
    }
    processHandler(byteProgress:number, loadedByte:number, totalByte:number, fileProgress:number, downloadedFiles:number, totalFiles:number) {
    }

}
