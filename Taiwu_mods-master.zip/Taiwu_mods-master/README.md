# Taiwu_mods
太吾绘卷游戏Mod


#编译依赖

1. 需要 unity tools for visuallstuio
2. 目标框架 Unity 3.5 .net subset Base Class Libraries
3. 各种unity的 dll
4. ActorMenu之类的在 Assembly-CSharp.dll里，有加密，解开即可

